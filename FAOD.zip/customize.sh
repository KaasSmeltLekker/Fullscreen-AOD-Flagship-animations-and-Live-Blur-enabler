#!/system/bin/sh

# Magisk/KernelSU module installation script for ts ahh module.

# Helper function for logging to Magisk Manager console
ui_print() {
  echo "$@"
}

ui_print "-------------------------------------------------"
ui_print "  aight lemme install ts nigga"
ui_print "-------------------------------------------------"
ui_print "- directly overlaying modified floating_feature.xml..."
ui_print "- ts module directly replaces the system's floating_feature.xml"
ui_print "- with your custom version via Magisk's systemless overlay."
ui_print "- bro ensure your provided floating_feature.xml is correct yea?"
ui_print "-------------------------------------------------"
ui_print "  module installation complete, go reboot your phone nigga."
ui_print "-------------------------------------------------"

exit 0 # Indicate successful installation
ssful installation
